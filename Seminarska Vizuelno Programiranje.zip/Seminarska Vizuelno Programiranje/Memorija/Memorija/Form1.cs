﻿using Memorija.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Memorija
{
    public partial class Form1 : Form
    {
        int vkupnoSec = 150;//vkupnite sekundi
        bool[] kliknatoKopce;//dali e kliknato kopce
        Button PrvoKopce;//prvo otvoreno kopce
        Button VtoroKopce;//vtoro otvoreno kopce
        int[] randomBroevi;//pole od random broevi koi ke se popolnuvaat vo kopcinjata
        int brojNaotvoreni;//vkupniot broj na otvoreni kopcinja
        int plusKopce;//treto kopce
        Button[] kopcinjata = new Button[36];//36 kopcinja za igranje
        int PrvoKopceVrednost;
        Image pozadinaKopcinja = Properties.Resources.slika;//pozadina na kopcinjata za igranje
        public Form1()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            button1.BackColor = Color.Orange;
            timer1.Interval = 1000;//go postavuvame tajmerot na 1 sekunda interval, da se namaaluva 1 sekunda
            button1.Font = new Font("Arial", 15);
            button1.FlatStyle = FlatStyle.System;
            button1.FlatAppearance.BorderSize = 1;
            label1.BackColor = Color.Red;
            label1.Font = new Font("Arial", 10);
            ZaVremeBox.BackColor = Color.Orange;
            ZaVremeBox.Font = new Font("Arial", 10);
            label2Rez.Font = new Font("Arial", 10);
            label2.Visible = false;
            label3.Visible = false;
            kopcinjata = new Button[36]//,inicijalizacija na kopcinjata za igranje
            {
                button2,button3,button4,button5,button6,button7,button8,button9,
                button10,button11,button12,button13,button14,button15,button16,
                button17,button18,button19,button20,button21,button22,button23,
                button24,button25,button26,button27,button28,button29,button30,
                button31,button32,button33,button34,button35,button36,button37
            };
            for (int i = 0; i < kopcinjata.Length; i++)
            {
                kopcinjata[i].BackgroundImage = pozadinaKopcinja;//postavuvame pozadina na niv
            }
            brojNaotvoreni = 0;//momentalno imame 0 otvoreni
            kliknatoKopce = new bool[36];//imame 36 kopcinja,koi mozat da bidat kliknati
            randomBroevi = new int[36];//pole od 36 random broevi koi treba da se popolnat vo 36te kopcinja

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            vkupnoSec = 150;
            timer1.Start();
            Random randomBroj = new Random();//so random gi raspredeluvame broevite vo razlicni kopcinja,pri sekoe pritiskanje na button1
            randomBroevi[0] = randomBroj.Next(1, 19);//broevite se random od 1 do 19
            int a;//promenliva za random broevite,integer promenliva
            int dveIsti = 0;//dve kopcinja so isti broevi,podole vo kodot
            for (int i = 0; i < 36; i++)
            {

            nazad:
                a = randomBroj.Next(1, 19);//a se postavuva za randomBroj bidejki e toj integer i treba pod pozadinata na kopcinjata da ima brojki
                dveIsti = 0;
                for (int j = 0; j < i; j++)
                {
                    if (randomBroevi[j] == a)
                    {
                        dveIsti++;
                        if (dveIsti == 2)//smee da ima po dve isti brojki,od random brojkite,ne povekje od dve
                        {
                            goto nazad;//se vrakja na pocetokot na labelata
                        }
                    }
                }
                randomBroevi[i] = a;//random broevite se dodeluvaat na a koja e promenliva za random broevite
                kliknatoKopce[i] = false;
                kopcinjata[i].Enabled = true;//moze da se klika na kopcinjata

            }
            
        }

        public void metoda(Button m, int vrednosti)//metoda sostvena od kopceto za koe e metodata(button2 do button37) i vrednosta vo nizata od 0 do 35 za nego
        {
            plusKopce++;
            int i = vrednosti;
            if (vkupnoSec == 0)//AKO ISTECAT SEKUNDITE nemame kliknato kopce
            {
                kliknatoKopce[i] = false;
                m.Text = "";
                PrvoKopce = null;
                VtoroKopce = null;
                PrvoKopceVrednost = 0;
                plusKopce = 0;
            }
            else
            {
                if (plusKopce == 3)//ako kliknemo treto kopce,se zatvarat drugite dve,ako ne se tocni
                {
                    for (int z = 0; z < 36; z++)
                    {
                        if (kopcinjata[z].Enabled)
                        {
                            kopcinjata[z].Text = "";//da ne se gledat brojkite preku pozadinata
                            kopcinjata[z].BackgroundImage = pozadinaKopcinja;
                        }

                        kliknatoKopce[z] = false;
                    }

                    PrvoKopce = null;//prvoto kliknato se zatvara
                    VtoroKopce = null;//vtoroto kliknato se zatvara
                    PrvoKopceVrednost = 0;
                }
                if (kliknatoKopce[i] == false && randomBroevi[i] != 0 && plusKopce != 3)//ako nemame kliknato kopce togaji imamo random broevi,i tretoto kopce ne e 3 togaj,moze da se klika
                {
                    kliknatoKopce[i] = true;
                }
                else//ako ne togaj ne moze da se klika i ne se gleda nivniot tekst odnosno ,brojkata  i i se stava pozadinata, potocno i se vrakja
                {
                    kliknatoKopce[i] = false;
                    m.Text = "";
                    m.BackgroundImage = pozadinaKopcinja;
                    PrvoKopce = null;
                    VtoroKopce = null;
                    PrvoKopceVrednost = 0;
                    plusKopce = 0;

                }
                if (randomBroevi[i] != 0 && kliknatoKopce[i] == true && PrvoKopceVrednost != 0)//ako imamo kliknato kopce togaj ,ako se isti se obojuvaat vo zeleno i ostanuvat takvi otvoreni,bez pozadina
                {
                    m.BackgroundImage = null;
                    m.Text = randomBroevi[i].ToString();
                    VtoroKopce = m;
                    if (Convert.ToInt32(PrvoKopce.Text) == Convert.ToInt32(VtoroKopce.Text))
                    {
                        brojNaotvoreni++;//ako pogodime dve isti brojot na otvoreni se zgolemuva
                        PrvoKopce.Enabled = false;
                        PrvoKopce.BackColor = Color.Green;
                        VtoroKopce.Enabled = false;
                        VtoroKopce.BackColor = Color.Green;
                        PrvoKopce = null;
                        VtoroKopce = null;
                        PrvoKopceVrednost = 0;
                        for (int y = 0; y < 36; y++)
                            kliknatoKopce[i] = false;
                        plusKopce = 0;
                    }
                    else
                    {
                        plusKopce = 2;

                    }
                }
                else if (randomBroevi[i] != 0 && kliknatoKopce[i] == true)//ako imame kliknato kopce ,i imame random broj za nego togaj se trga pozadina,tekstot na kopceto e toj random broj,i vrednosta se dodeluva
                {
                    m.BackgroundImage = null;
                    m.Text = randomBroevi[i].ToString();
                    PrvoKopce = m;
                    PrvoKopceVrednost = Convert.ToInt32(PrvoKopce.Text);
                }
            }
            for (int c = 0; c < 36; c++)
            {
                if (kopcinjata[c].Enabled)
                    break;
                else if (c == 35)//ako se otvoreni site kopcinja
                {
                    label2.Visible = true;
                    label2.Text = "Победивте";
                    timer1.Stop();//ako se otovreni site togaj
                    timer1.Enabled = false;
                }
            }


        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string vremeto = vkupnoSec / 60 + ":" + vkupnoSec % 60;//formula za vremeto,/60 za dobivanje na minuti,&60 za sekundi,treba saato da bide vo format 2:30
            vkupnoSec--;//so aktviranje na vremeto se namaluva promenliva vkupnoSec ,koja pretstavuva vkupnite sekundi
            ZaVremeBox.Text = vremeto;//vremeto se prikazuva vo textbox 
            if (vkupnoSec == 0)//ako  ima 0 sekundi uslovot
            {
                label3.Visible = true;
                label2.Visible = true;
                if (brojNaotvoreni == 0)//ako imame nula otvoreni parovi togaj dava poraka deka ima 0 otvoreni
                {
                    label2.Text = "0 отворени ";
                }
                else
                {
                    label2.Text = "Повеќе среќа следниот пат";//ako nemame 0 otvoreni dava povekje srekaj sledniot pat
                    label3.Visible = true;
                    label3.Text = "Отворивте:" + brojNaotvoreni;//go prikazuva brojot na otvoreni parovi
                }
                
                timer1.Stop();//zapira da broi casovnikot,ako ima nula sekundi ostanati
            }
            
        }
        //podole site kopcinja ja referenciraat glavnata metoda za pronaogjanje na dve isti brojki  vo kopcinjata i nivno otkrivanje ,i boenje vo zeleno,koi stanuvaat vidlivi se do pritiskanje na drugo kopce,plus kopce
        private void button2_Click(object sender, EventArgs e)
        {
            metoda(button2, 0);
        }
        private void button3_Click(object sender, EventArgs e)
        {
            metoda(button3, 1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            metoda(button4, 2);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            metoda(button5, 3);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            metoda(button6, 4);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            metoda(button7, 5);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            metoda(button8, 6);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            metoda(button9, 7);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            metoda(button10, 8);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            metoda(button11, 9);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            metoda(button12, 10);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            metoda(button13, 11);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            metoda(button14, 12);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            metoda(button15, 13);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            metoda(button16, 14);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            metoda(button17, 15);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            metoda(button18, 16);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            metoda(button19, 17);
        }

        private void button20_Click(object sender, EventArgs e)
        {
            metoda(button20, 18);
        }

        private void button21_Click(object sender, EventArgs e)
        {
            metoda(button21, 19);
        }

        private void button22_Click(object sender, EventArgs e)
        {
            metoda(button22, 20);
        }

        private void button23_Click(object sender, EventArgs e)
        {
            metoda(button23, 21);
        }

        private void button24_Click(object sender, EventArgs e)
        {
            metoda(button24, 22);
        }

        private void button25_Click(object sender, EventArgs e)
        {
            metoda(button25, 23);
        }

        private void button26_Click(object sender, EventArgs e)
        {
            metoda(button26, 24);
        }

        private void button27_Click(object sender, EventArgs e)
        {
            metoda(button27, 25);
        }

        private void button28_Click(object sender, EventArgs e)
        {
            metoda(button28, 26);
        }

        private void button29_Click(object sender, EventArgs e)
        {
            metoda(button29, 27);
        }

        private void button30_Click(object sender, EventArgs e)
        {
            metoda(button30, 28);
        }

        private void button31_Click(object sender, EventArgs e)
        {
            metoda(button31, 29);
        }

        private void button32_Click(object sender, EventArgs e)
        {
            metoda(button32, 30);
        }

        private void button33_Click(object sender, EventArgs e)
        {
            metoda(button33, 31);
        }

        private void button34_Click(object sender, EventArgs e)
        {
            metoda(button34, 32);
        }

        private void button35_Click(object sender, EventArgs e)
        {
            metoda(button35, 33);
        }

        private void button36_Click(object sender, EventArgs e)
        {
            metoda(button36, 34);
        }

        private void button37_Click(object sender, EventArgs e)
        {
            metoda(button37, 35);
        }
    }
}
