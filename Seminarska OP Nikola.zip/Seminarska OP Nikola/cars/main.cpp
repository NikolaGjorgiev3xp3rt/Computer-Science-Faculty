#include <iostream>
#include <fstream>
#include <string>
#include <ctime>
#include <ctype.h>

using namespace std;

struct Avtomobil
{
    int km;
    string s_ime, s_prezime, rbroj;
    time_t priem;
};

time_t vreme(time_t vr)
{
    vr = time(NULL);

    tm *tm_local = localtime(&vr);
    cout <<"Vreme na priem: "<<tm_local->tm_hour<<":"<<tm_local->tm_min<<endl;
}

bool reg(string br)
{
    if(!isupper(br[0]) || !isupper(br[1]))
        return false;
    if(!isupper(br[8]) || !isupper(br[9]))
        return false;
    if(br[2] != '-' || br[7] != '-')
        return false;
    if(!isdigit(br[3]) || !isdigit(br[4]) || !isdigit(br[5]) || !isdigit(br[6]))
        return false;
    return true;
}

void costumer(Avtomobil a[],int &n)
{
    string ime, prezime, rbr;
    int km=0;
    time_t priem;

    do
    {
        cout<<"Vnesete ime: ";
        cin>>ime;
        if(ime=="" || ime.length()>15)
        {
            cout<<"Vnesete ime do 15 karakteri! "<<endl;
        }
    }while(ime=="" || ime.length()>15);

    do
    {
        cout<<"Vnesete prezime: ";
        cin>>prezime;
        if(prezime=="" || prezime.length()>15)
        {
            cout<<"Vnesete prezime do 15 karakteri!"<<endl;
        }
    }while(prezime=="" || prezime.length()>15);

    do
    {
        cout<<"Vnesete registarski broj: ";
        cin>>rbr;
        if(!reg(rbr))
        {
            cout<<"Vnesete registarski broj vo format \"SK-001-AA\"!"<<endl;
        }
    }while(!reg(rbr));

    do
    {
        cout<<"Vnesete kolku kilometri se izvozeni so voziloto: ";
        cin>>km;
        if(km<0 || km>500000)
        {
            cout<<"Vnesete brojka od 0 do 500 000!"<<endl;
        }
    }while(km<0 || km>500000);

    a[n].s_ime=ime;
    a[n].s_prezime=prezime;
    a[n].rbroj=rbr;
    a[n].km=km;
    a[n].priem=vreme(priem);

    n++;
}

void service(Avtomobil a)
{
    int cena=0;
    int rab=0;
    time_t vr = time(NULL);
    tm *tm_local = localtime(&vr);

    do
    {
            if(a.km>=10000)
        {
            cena+=4000;
            rab+=90;
            cout<<"Filtri i maslo"<<endl;
        }
        if(a.km>=30000)
        {
            cena+=5000;
            rab+=120;
            cout<<"Diskovi za kocenje"<<endl;
        }
        if(a.km>=40000)
        {
            cena+=8000;
            rab+=45;
            cout<<"Diskovi za gumi"<<endl;
        }
        if(a.km>=60000)
        {
            cena+=6000;
            rab+=150;
            cout<<"Rebrasti i klinesti kaisi"<<endl;
        }
    }while(a.km<0 || a.km>500000);
    cout<<"Cena: "<<cena<<" denari."<<endl;
    cout<<"Vreme na podignuvanje: "<<tm_local->tm_hour+(rab/60)<<":"<<tm_local->tm_min+(rab%60)<<endl;
}


void pecati(Avtomobil a)
{
    cout<<"\nIme: "<<a.s_ime<<endl;
    cout<<"Prezime: "<<a.s_prezime<<endl;
    cout<<"Registarski broj: "<<a.rbroj<<endl;
    cout<<"Promeneti delovi: "<<endl;
    service(a);

}

void Write(Avtomobil a[], int &n)
{
    ofstream write;
    write.open("vozilo.dat");
    if(!write)
    {
        cout<<"Greska pri kreiranje na vozilo.dat"<<endl;
    }
    else
    {
        for(int i=0; i<n-1; i++)
        {
            write<<a[i].s_ime<<" ";
            write<<a[i].s_prezime<<" ";
            write<<a[i].rbroj<<" ";
            write<<a[i].km<<" ";
            write<<a[i].priem<<"\n";
        }

        write<<a[n-1].s_ime<<" ";
        write<<a[n-1].s_prezime<<" ";
        write<<a[n-1].rbroj<<" ";
        write<<a[n-1].km<<" ";
        write<<a[n-1].priem<<" ";

        write.close();
    }
}

void Read(Avtomobil a[], int &n)
{
    ifstream read;
    read.open("vozilo.dat");
    if(!read)
        cout<<"Greska pri otvaranje na vozilo.dat!"<<endl;
    else
    {
        for(int i=0; i<n; i++)
        {
            read>>a[i].s_ime;
            read>>a[i].s_prezime;
            read>>a[i].rbroj;
            read>>a[i].km;
            read>>a[i].priem;
        }
    }
}

void Sort(Avtomobil a[], int n)
{
    ofstream write;
    write.open("vnos.dat");
    if(!write)
    {
        cout<<"Greska pri kreiranje na vnos.dat"<<endl;
    }
    else
    {
        for(int i=0; i<n-1; i++)
        {
            write<<a[i].s_ime<<" ";
            write<<a[i].s_prezime<<" ";
            write<<a[i].rbroj<<"\n";
        }

        write<<a[n-1].s_ime<<" ";
        write<<a[n-1].s_prezime<<" ";
        write<<a[n-1].rbroj<<" ";

        write.close();
    }

    int j, k;
    char min;
    Avtomobil temp;
    for(int i=0; i<n; i++)
    {
        min=toupper(a[i].s_ime[0]);
        k=i;
        for(j=i; j<n; j++)
            if(toupper(a[j].s_ime[0]) < min)
            {
                min = toupper(a[k].s_ime[0]);
                k=j;
            }
            temp = a[i];
            a[i] = a[k];
            a[k] = temp;
    }
}

int main()
{
    Avtomobil avto[100];
    int n=0, nov=0;

    do
    {
        costumer(avto, n);
        cout<<"Nova kola? [0=NE, 1=DA] ";
        cin>>nov;
    }while (nov==1);
    Write(avto, n);
    Read(avto, n);
    Sort(avto, n);
    for(int i=0; i<n; i++)
    {
        pecati(avto[i]);
    }

    system("pause");
    return 0;
}

