#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

class PolovnoVozilo
{
	protected:
	char marka[50];
	char model[50];
	int god_proizvodstvo;
	int pominati_kilometri;
	char boja[30];
	int cena;
	public:
		PolovnoVozilo(){};
		PolovnoVozilo(const char *mar,const char *mod,int god,int pom_kil,const char *bj,int cen){
				strcpy(marka,mar);
				strcpy(model,mod);
				god_proizvodstvo=god;
				pominati_kilometri=pom_kil;
				strcpy(boja,bj);
				cena=cen;
			}
        void Set(char *mar,char *mod,int god,int pom_kil,char *bj,int cen);
				
		char *returnMarka(){
		return marka;
		}
		char *returnModel(){
		return model;
		}
		int returnGodina(){
		return god_proizvodstvo;
		}
		int returnKilometri(){
		return pominati_kilometri ;
		}
		char *returnBoja(){
		return boja;
		}
		int returnCena(){
		return cena;
		}
		virtual float danok()=0;
		virtual void pecati()=0;
};
void PolovnoVozilo::Set(char *mar,char *mod,int god,int pom_kil,char *bj,int cen){
	            strcpy(marka,mar);
				strcpy(model,mod);
				god_proizvodstvo=god;
				pominati_kilometri=pom_kil;
				strcpy(boja,bj);
				cena=cen;
}
class Avtomobil:public PolovnoVozilo
{
	private:
		char karoserija[40];
	public:
		Avtomobil(){};
	    Avtomobil(const char *mar,const char *mod,int god,int pom_kil,const char *bj,int cen,const char *karos):PolovnoVozilo(mar,mod,god,pom_kil,bj,cen)
		{
	    	strcpy(karoserija,karos);
		}
		void setAvtomobil(char *mar,char *mod,int god,int pom_kil,char *bj,int cen,char *karos){
		        strcpy(marka,mar);
				strcpy(model,mod);
				god_proizvodstvo=god;
				pominati_kilometri=pom_kil;
				strcpy(boja,bj);
				cena=cen;
				strcpy(karoserija,karos);	
		}
		char *returnKaroserija(){
			return karoserija;
		}	
		
		virtual float danok(){
       	float danokot;
       	if(cena<=10000){
       		danokot=cena*0.1;
		   }
		if(cena>10000 && cena<=30000){
       		danokot=cena*0.4;
		   }
		if(cena>30000 && cena<=50000){
       		danokot=cena*0.7;
		   }
		if(cena>50000){
       		danokot=cena*0.9;
		   }
		   return danokot;
	   }
	   virtual void pecati(){	
		cout<<"Marka na avtomobil:"<<returnMarka()<<endl;
		cout<<"Karoserija:"<<returnKaroserija()<<endl;
		cout<<"Model od taa marka: "<<returnModel()<<endl;
		cout<<"Godina na proizvodstvo:"<<returnGodina()<<endl;
		cout<<"Pominati kilometri: "<<returnKilometri()<<endl;
		cout<<"Boja na avtomobil:"<<returnBoja()<<endl;
		cout<<"Cena na avtomobil:"<<returnCena()<<endl;
		cout<<"Danok:"<<danok()<<endl;
		cout<<endl;
		}
	   bool operator>(Avtomobil &av){ return cena>av.cena;}
	
};   
class Kamion:public PolovnoVozilo
{
	private:
		char sasija[40];
	public:
		Kamion(){};
	    Kamion(const char *mar,const char *mod,int god,int pom_kil,const char *bj,int cen,const char *sas):PolovnoVozilo(mar,mod,god,pom_kil,bj,cen)
		{
	    	strcpy(sasija,sas);
		}
		void setKamion(char *mar,char *mod,int god,int pom_kil,char *bj,int cen,char *sas){
		        strcpy(marka,mar);
				strcpy(model,mod);
				god_proizvodstvo=god;
				pominati_kilometri=pom_kil;
				strcpy(boja,bj);
				cena=cen;
				strcpy(sasija,sas);	
		}
		char *returnSasija(){
			return sasija;
		}	
		
		virtual float danok(){
       	float danokot;
       	if(cena<=10000){
       		danokot=cena*0.1;
		   }
		if(cena>10000 && cena<=30000){
       		danokot=cena*0.4;
		   }
		if(cena>30000 && cena<=50000){
       		danokot=cena*0.7;
		   }
		if(cena>50000){
       		danokot=cena*0.9;
		   }
		   return danokot;
	   }
	   virtual void pecati(){	
		cout<<"Marka na kamion:"<<returnMarka()<<endl;
		cout<<"Model od taa marka: "<<returnModel()<<endl;
		cout<<"Sasija:"<<returnSasija()<<endl;
		cout<<"Godina na proizvodstvo:"<<returnGodina()<<endl;
		cout<<"Pominati kilometri: "<<returnKilometri()<<endl;
		cout<<"Boja na kamion:"<<returnBoja()<<endl;
		cout<<"Cena na kamion:"<<returnCena()<<endl;
		cout<<"Danok:"<<danok()<<endl;
		cout<<endl;
		}
	   bool operator>(Kamion &ka){ return cena>ka.cena;}			
};
class ZaNas
{
	private:
	char ime[30];
	char drzava[40];
	char grad[40];
	char ulica[40];
	int br_vraboteni;
	int buget;
	int vozila;
	public:
		ZaNas(){};
		ZaNas(const char *im,const char *dr,const char *gr,const char *ul,int br_v,int bug,int veh){
			strcpy(ime,im);
			strcpy(drzava,dr);
			strcpy(grad,gr);
			strcpy(ulica,ul);
			br_vraboteni=br_v;
			buget=bug;
			vozila=veh;
		}
		void pecatiZaNas(){
			cout<<"Ime:"<<ime<<endl;
				cout<<"Drzava:"<<drzava<<endl;
					cout<<"Grad:"<<grad<<endl;
						cout<<"Ulica:"<<ulica<<endl;
							cout<<"Broj na Vraboteni:"<<br_vraboteni<<endl;
								cout<<"Buget:"<<buget<<" evra"<<endl;
								cout<<"Broj na dostapni vozila: "<<vozila<<endl;
		}
		
		
};
template<class X>void Sort(X a[],int n){
	X p,max;
	int i,j,maxpoz;
	for(i=0;i<n-1;++i){
	max=a[i];
	maxpoz=i;
	for(j=i+1;j<n;++j){
		if(a[j]>max){
			max=a[j];
			maxpoz=j;
		}
		if(i!=maxpoz){
			p=a[i];
			a[i]=a[maxpoz];
			a[maxpoz]=p;
		    }
	     }
	  }
	}
class Isklucokot {
public:
	char isk[80];
	Isklucokot() { *isk = 0; }
	Isklucokot(const char *i) { strcpy(isk, i); }
};
int main() {
	Avtomobil A[1000];
	Kamion K[1000];
	ZaNas *w=new ZaNas("AutoExtra","Makedonija","Sveti Nikole","Krste Misrokov",14,1200000,245);
    char marka1[40],marka2[40],model1[40],model2[40],boja1[40],boja2[40],karoserijaZaKola[40],sasijaZaKamion[40];
    int  godina1,godina2,kilometri1,kilometri2,cena1,cena2;
    int zaKola=0,zaKamion=0;
    int izbor;
    int i,j;
    do{
	cout<<"PRODAVNICA ZA POLOVNI VOZILA"<<endl;
		cout<<"1.Vnesi Avtomobil"<<endl;
		cout<<"2.Pecati Avtomobil"<<endl;
		cout<<"3.Sortiraj avtomobili spored cena"<<endl;
		cout<<"4.Vnesi Kamion"<<endl;
		cout<<"5.Pecati Kamion"<<endl;
		cout<<"6.Sortiraj kamioni spored cena"<<endl;
		cout<<"7.Za nas"<<endl;
		cout<<"8.Izlez"<<endl;
		cin>>izbor;
		switch(izbor)
		{
			case 1:		
			cout<<"Vnesi marka na avtomobil:"<<endl;
			cin>>marka1;
			cout<<"Vnesi karoserija(sedan,hedzbek,dzip) na avtomobil:"<<endl;
			cin>>karoserijaZaKola;
			cout<<"Vnesi model za avtomobil:"<<endl;
			cin>>model1;
			cout<<"Vnesi godina na proizvodstvo na avtomobil:"<<endl;
			cin>>godina1;
			cout<<"Vnesi pominati kilometri na avtomobil:"<<endl;
			cin>>kilometri1;
			cout<<"Vnesi boja na avtomobil:"<<endl;
			cin>>boja1;
			cout<<"Vnesi cena na avtomobil:"<<endl;
			cin>>cena1;
			A[zaKola].setAvtomobil(marka1,model1,godina1,kilometri1,boja1,cena1,karoserijaZaKola);
			zaKola++;
            break;
        case 2:
        	for(i=0;i<zaKola;i++) 
			A[i].pecati();
            break;
        case 3:
        	Sort(A,zaKola);
				for(i=0;i<zaKola;i++)
				{
					A[i].pecati();
				}
            break;
        case 4:
			cout<<"Vnesi marka na kamion:"<<endl;
			cin>>marka2;
			cout<<"Vnesi model na taa marka:"<<endl;
			cin>>model2;
			cout<<"Vnesi sasija:"<<endl;
			cin>>sasijaZaKamion;
			cout<<"Vnesi godina na proizvodstvo na kamion:"<<endl;
			cin>>godina2;
			cout<<"Vnesi pominati kilometri na kamion:"<<endl;
			cin>>kilometri2;
			cout<<"Vnesi boja na kamion:"<<endl;
			cin>>boja2;
			cout<<"Vnesi cena na kamion:"<<endl;
			cin>>cena2;
			K[zaKamion].setKamion(marka2,model2,godina2,kilometri2,boja2,cena2,sasijaZaKamion);
			zaKamion++;
            break;
        case 5:
        	for(j=0;j<zaKamion;j++) 
			K[j].pecati();
            break;
        case 6:
        Sort(K,zaKamion);
				for(j=0;j<zaKamion;j++)
				{
					A[j].pecati();
				}
            break;
		case 7:
		 w->pecatiZaNas();	
		}
	}while(izbor<8);
	try {
		if(izbor>=9)
		       throw Isklucokot("Izborot na menito ne moze da e pogolem od 8" );		       
	}
	catch (Isklucokot I) { 
		cout << I.isk <<endl;
	}
	ofstream dat;
	dat.open("avtomobil.txt",ios::out);
	dat<<marka1<<" "<<model1<<" "<<karoserijaZaKola<<" "<<godina1<<" "<<kilometri1<<" "<<boja1<<" "<<cena1<<" ";
    dat.close();
    ofstream dat2;
	dat2.open("kamion.txt",ios::out);
	dat2<<marka2<<" "<<model2<<" "<<sasijaZaKamion<<" "<<godina2<<" "<<kilometri2<<" "<<boja2<<" "<<cena1<<" ";
    dat2.close();
    
	delete w;
	return 0;
}
